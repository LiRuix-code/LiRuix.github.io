// 新增功能：1. 时间轴搜索筛选
function addSearchFunction() {
  // 创建搜索容器
  const header = document.querySelector('header');
  const searchContainer = document.createElement('div');
  searchContainer.className = 'search-container';
  searchContainer.innerHTML = `
    <input type="text" id="timeline-search" placeholder="搜索年份/事件（如1992、WTO）">
    <button id="search-btn">搜索</button>
    <button id="reset-search">重置</button>
  `;
  header.after(searchContainer);

  // 搜索逻辑
  const searchInput = document.getElementById('timeline-search');
  const searchBtn = document.getElementById('search-btn');
  const resetBtn = document.getElementById('reset-search');
  const timelineItems = document.querySelectorAll('.timeline-item');

  // 搜索事件
  function handleSearch() {
    const searchText = searchInput.value.trim().toLowerCase();
    timelineItems.forEach(item => {
      const year = item.querySelector('.timeline-year').textContent.toLowerCase();
      const title = item.querySelector('h3').textContent.toLowerCase();
      const content = item.querySelector('p').textContent.toLowerCase();
      
      // 匹配年份/标题/内容任一关键词
      if (year.includes(searchText) || title.includes(searchText) || content.includes(searchText)) {
        item.style.display = '';
        // 匹配项高亮（3秒后自动取消）
        item.style.borderLeft = '4px solid #e74c3c';
        setTimeout(() => item.style.borderLeft = '', 3000);
      } else {
        item.style.display = 'none';
      }
    });
  }

  // 重置事件
  function handleReset() {
    searchInput.value = '';
    timelineItems.forEach(item => {
      item.style.display = '';
      item.style.borderLeft = '';
    });
  }

  searchBtn.addEventListener('click', handleSearch);
  searchInput.addEventListener('keyup', (e) => e.key === 'Enter' && handleSearch());
  resetBtn.addEventListener('click', handleReset);
}

// 新增功能：2. 年份导航栏
function addYearNavigation() {
  // 创建导航容器
  const timeline = document.querySelector('.timeline');
  const navContainer = document.createElement('div');
  navContainer.className = 'year-nav';
  navContainer.innerHTML = `
    <h3>年代导航</h3>
    <button class="nav-btn" data-decade="1978">1970s</button>
    <button class="nav-btn" data-decade="1982">1980s</button>
    <button class="nav-btn" data-decade="1990">1990s</button>
    <button class="nav-btn" data-decade="2001">2000s</button>
    <button class="nav-btn" data-decade="2013">2010s</button>
    <button class="nav-btn" data-decade="2020">2020s</button>
  `;
  timeline.before(navContainer);

  // 导航跳转逻辑
  const navBtns = document.querySelectorAll('.nav-btn');
  navBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetDecade = btn.getAttribute('data-decade');
      // 找到对应年代的第一个时间轴项
      const targetItem = Array.from(document.querySelectorAll('.timeline-item')).find(item => {
        const year = item.querySelector('.timeline-year').textContent;
        return year.startsWith(targetDecade);
      });
      
      // 平滑滚动到目标项
      if (targetItem) {
        targetItem.scrollIntoView({ behavior: 'smooth', block: 'center' });
        // 高亮当前导航按钮
        navBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
      }
    });
  });
}

// 新增功能：3. 答题解析功能（基于原有quizData扩展）
const quizWithExplanations = [
  {
    question: "改革开放开始的标志性事件是？",
    options: ["十一届三中全会", "南方谈话", "加入WTO"],
    answer: 0,
    explanation: "1978年十一届三中全会明确提出“把全党工作重点转移到社会主义现代化建设上来”，标志着改革开放正式启动；南方谈话（1992）确立市场经济方向，加入WTO（2001）是对外开放新阶段。"
  },
  {
    question: "中国特色社会主义经济体制的本质特征是？",
    options: ["计划经济", "市场经济", "社会主义市场经济"],
    answer: 2,
    explanation: "中国并非纯计划经济（改革开放前）或纯市场经济（西方模式），而是“社会主义市场经济”——坚持公有制为主体，同时发挥市场在资源配置中的决定性作用。"
  },
  {
    question: "1992年南方谈话提出的重要观点是？",
    options: ["发展是硬道理", "阶级斗争为纲", "两个凡是"],
    answer: 0,
    explanation:"南方谈话核心观点包括“发展是硬道理”“计划和市场都是经济手段”“三个有利于”阶级斗争为纲是文革时期口号,两个凡是是改革开放前的思想方针."
  }
];

function addQuizExplanations() {
  const submitBtn = document.getElementById('submit');
  const resultsDiv = document.getElementById('results');

  if (!submitBtn || !resultsDiv) {
    console.error('找不到答题相关元素，请检查HTML结构');
    return;
  }

  // 重写提交答案逻辑（保留原得分，新增解析）
  function submitQuizWithExplanations() {
    let score = 0;
    let explanationsHtml = '<div class="quiz-explanations"><h4>答题解析</h4>';

    quizWithExplanations.forEach((item, index) => {
      const selected = document.querySelector(`input[name="question${index}"]:checked`);
      const isCorrect = selected && parseInt(selected.value) === item.answer;
      
      if (isCorrect) score++;

      // 构建每题解析
      explanationsHtml += `
        <div class="question-explanation ${isCorrect ? 'correct' : 'incorrect'}">
          <p><strong>第${index+1}题：</strong>${item.question}</p>
          <p>${isCorrect ? '✅ 回答正确' : `❌ 回答错误（正确答案：${item.options[item.answer]}）`}</p>
          <p><small>解析：${item.explanation}</small></p>
        </div>
      `;
    });

    explanationsHtml += '</div>';
    // 显示得分+解析
    resultsDiv.innerHTML = `<h3>你的得分: ${score}/${quizWithExplanations.length}</h3>${explanationsHtml}`;
    resultsDiv.style.display = 'block';
  }

  // 移除可能存在的旧事件监听器，添加新的事件监听器
  const newSubmitBtn = submitBtn.cloneNode(true);
  submitBtn.parentNode.replaceChild(newSubmitBtn, submitBtn);
  newSubmitBtn.addEventListener('click', submitQuizWithExplanations);
}

// 新增功能：4. 暗黑模式切换
function addDarkMode() {
  // 创建切换按钮
  const footer = document.querySelector('footer');
  if (!footer) {
    console.error('找不到footer元素');
    return;
  }

  const darkModeBtn = document.createElement('button');
  darkModeBtn.id = 'dark-mode-btn';
  darkModeBtn.textContent = '切换暗黑模式';
  footer.before(darkModeBtn);

  // 暗黑模式样式
  const darkStyle = document.createElement('style');
  darkStyle.id = 'dark-mode-style';
  darkStyle.textContent = `
    .dark-mode {
      background-color: #1a1a1a;
      color: #f0f0f0;
    }
    .dark-mode header {
      background: linear-gradient(to right, #991118, #b83329);
    }
    .dark-mode .timeline-content, 
    .dark-mode .quiz-container, 
    .dark-mode .popup-content,
    .dark-mode .detail-section,
    .dark-mode .question {
      background-color: #2d2d2d;
      color: #f0f0f0;
    }
    .dark-mode table td, .dark-mode table th {
      border-bottom: 1px solid #444;
    }
    .dark-mode input[type="text"], .dark-mode input[type="radio"] + label {
      color: #f0f0f0;
      background-color: #2d2d2d;
      border: 1px solid #444;
    }
    .dark-mode .correct { color: #4cd964; }
    .dark-mode .incorrect { color: #ff6b6b; }
  `;
  document.head.appendChild(darkStyle);
  darkStyle.disabled = true; // 默认隐藏暗黑样式

  // 切换逻辑
  darkModeBtn.addEventListener('click', () => {
    const body = document.body;
    const isDark = body.classList.toggle('dark-mode');
    
    // 切换样式和按钮文字
    darkStyle.disabled = !isDark;
    darkModeBtn.textContent = isDark ? '切换浅色模式' : '切换暗黑模式';
    
    // 保存用户偏好（刷新后仍生效）
    localStorage.setItem('darkMode', isDark ? 'on' : 'off');
  });

  // 加载时恢复用户偏好
  if (localStorage.getItem('darkMode') === 'on') {
    document.body.classList.add('dark-mode');
    darkStyle.disabled = false;
    darkModeBtn.textContent = '切换浅色模式';
  }
}
// 更通用的暗黑模式GDP样式解决方案
// 在 enhanceDarkModeForGDP 函数中添加图片文字优化样式
function enhanceDarkModeForGDP() {
  const darkStyle = document.querySelector('#dark-mode-style');
  if (darkStyle) {
    // 获取现有样式并添加GDP相关样式
    const existingStyle = darkStyle.textContent;
    darkStyle.textContent = existingStyle + `
      /* GDP数据暗黑模式优化 */
      .dark-mode .gdp-data,
      .dark-mode [class*="gdp"],
      .dark-mode [class*="data"],
      .dark-mode .timeline-item p strong,
      .dark-mode .timeline-item p b {
        color: #ffd700 !important;
        font-weight: bold;
        background-color: rgba(0, 0, 0, 0.3);
        padding: 2px 4px;
        border-radius: 3px;
      }
      
      /* 确保所有文字在暗黑模式下可读 */
      .dark-mode .timeline-content * {
        color: #e0e0e0;
      }
      
      /* 特别处理深色文字 */
      .dark-mode .timeline-content .dark-text {
        color: #ffffff !important;
      }

      /* 新增：图片文字暗黑模式优化 */
      .dark-mode .timeline-image {
        position: relative;
        border: 2px solid #555;
      }
      
      /* 为图片添加半透明遮罩，提高文字可读性 */
      .dark-mode .timeline-image::after {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.3);
        pointer-events: none;
        border-radius: 5px;
      }
      
      /* 计算器相关暗黑模式优化 */
      .dark-mode .calculator-container {
        background: linear-gradient(135deg, #2d3748 0%, #4a5568 100%);
        color: #e2e8f0;
      }
      
      .dark-mode .calculator-results {
        background-color: #2d3748;
        color: #e2e8f0;
      }
      
      .dark-mode .stat-card {
        background: linear-gradient(135deg, #805ad5 0%, #6b46c1 100%);
      }
      
      .dark-mode .analysis-section,
      .dark-mode .milestones-section,
      .dark-mode .comparison-section,
      .dark-mode .personal-timeline {
        background-color: #4a5568;
        color: #e2e8f0;
      }
      
      .dark-mode .milestone {
        background-color: #2d3748;
        border-left-color: #68d391;
      }
      
      .dark-mode .economic-stats {
        background-color: #2d3748;
        border-color: #4a5568;
      }
      
      .dark-mode .personal-event {
        background-color: #2d3748;
        box-shadow: 0 2px 5px rgba(0,0,0,0.3);
      }
      
      .dark-mode .milestone-year,
      .dark-mode .event-year {
        color: #fbb6ce;
      }
      
      .dark-mode #birth-year {
        background-color: #2d3748;
        color: #e2e8f0;
        border-color: #4a5568;
      }
      
      .dark-mode #birth-year:focus {
        border-color: #fbb6ce;
      }
      
      .dark-mode .input-group label {
        color: #e2e8f0;
      }
      
      .dark-mode .debug-info {
        color: #a0aec0 !important;
      }
    `;
  }
}

// 新增功能：5. 搜索和导航的样式补充（避免与原样式冲突）
function addEnhancementStyles() {
  const style = document.createElement('style');
  style.textContent = `
    /* 搜索容器样式 */
    .search-container {
      margin: 20px 0;
      display: flex;
      gap: 10px;
      padding: 0 20px;
      justify-content: center;
      align-items: center;
    }
    #timeline-search {
      flex: 1;
      max-width: 300px;
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 5px;
      font-size: 1em;
    }
    .search-container button {
      padding: 10px 15px;
      background-color: #c8161d;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
    .search-container button:hover {
      background-color: #a01217;
    }

    /* 年份导航样式 */
    .year-nav {
      margin: 30px 0;
      padding: 0 20px;
      text-align: center;
    }
    .year-nav h3 {
      color: #c8161d;
      margin-bottom: 10px;
    }
    .nav-btn {
      margin: 0 5px 10px 0;
      padding: 8px 12px;
      background-color: #f0f0f0;
      color: #333;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      transition: all 0.3s;
    }
    .nav-btn:hover {
      background-color: #ddd;
    }
    .nav-btn.active {
      background-color: #c8161d;
      color: white;
    }

    /* 答题解析样式 */
    .quiz-explanations {
      margin-top: 20px;
      padding-top: 20px;
      border-top: 1px solid #ddd;
    }
    .question-explanation {
      margin: 10px 0;
      padding: 10px;
      border-radius: 5px;
      background-color: #f9f9f9;
    }
    .dark-mode .question-explanation {
      background-color: #333;
    }
    .correct { 
      border-left: 4px solid #4cd964;
      background-color: #f0fff0 !important;
    }
    .dark-mode .correct {
      background-color: #1a331a !important;
    }
    .incorrect { 
      border-left: 4px solid #ff6b6b;
      background-color: #fff0f0 !important;
    }
    .dark-mode .incorrect {
      background-color: #331a1a !important;
    }

    /* 暗黑模式按钮样式 */
    #dark-mode-btn {
      margin: 20px auto;
      display: block;
      padding: 10px 20px;
      background-color: #333;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 1em;
    }
    #dark-mode-btn:hover {
      background-color: #555;
    }

    /* 响应式适配 */
    @media (max-width: 768px) {
      .search-container {
        flex-direction: column;
        align-items: stretch;
      }
      #timeline-search {
        max-width: none;
      }
      .year-nav {
        overflow-x: auto;
        padding-bottom: 10px;
        white-space: nowrap;
      }
      .nav-btn {
        white-space: nowrap;
      }
    }
  `;
  document.head.appendChild(style);
}


// 新增功能：改革开放成就计算器
// 修改后的改革开放成就计算器函数
function addReformCalculator() {
    // 创建计算器容器
    const quizContainer = document.querySelector('.quiz-container');
    const calculatorContainer = document.createElement('div');
    calculatorContainer.className = 'calculator-container';
    calculatorContainer.innerHTML = `
        <h2>改革开放成就计算器</h2>
        <div class="calculator-form">
            <div class="input-group">
                <label for="birth-year">请输入您的出生年份：</label>
                <input type="number" id="birth-year" min="1900" max="2024" placeholder="例如：1990">
            </div>
            <button id="calculate-btn">计算我的改革开放历程</button>
        </div>
        <div id="calculator-results" class="calculator-results"></div>
    `;
    quizContainer.after(calculatorContainer);

    // 计算逻辑
    const calculateBtn = document.getElementById('calculate-btn');
    const birthYearInput = document.getElementById('birth-year');
    const resultsDiv = document.getElementById('calculator-results');

    calculateBtn.addEventListener('click', calculateReformJourney);

    // 替换原来的重叠度计算部分
function calculateReformJourney() {
    const birthYear = parseInt(birthYearInput.value);
    const currentYear = new Date().getFullYear();
    const reformStartYear = 1978;

    if (!birthYear || birthYear < 1900 || birthYear > 2024) {
        resultsDiv.innerHTML = '<p class="error">请输入有效的出生年份（1900-2024）</p>';
        return;
    }

    // 重新定义计算逻辑
    const totalReformYears = currentYear - reformStartYear; // 改革开放总年数
    const personalReformYears = Math.max(0, currentYear - Math.max(birthYear, reformStartYear)); // 个人经历的年数
    
    // 新的重叠度计算：个人经历年数占改革开放总年数的比例
    let lifePercentage;
    if (birthYear <= reformStartYear) {
        // 1978年或之前出生，经历了完整的改革开放
        lifePercentage = 100;
    } else {
        // 1978年之后出生，按实际经历比例计算
        lifePercentage = ((personalReformYears / totalReformYears) * 100).toFixed(1);
    }

    // 其余代码保持不变...
    const ageAtReformStart = birthYear - reformStartYear;
    let analysis = generatePersonalAnalysis(birthYear, ageAtReformStart, personalReformYears);
    let milestones = generatePersonalMilestones(birthYear);
    let comparison = generateEconomicComparison(birthYear);

    resultsDiv.innerHTML = `
        <div class="results-header">
            <h3>您的改革开放成长报告</h3>
            <p class="user-age">出生于 ${birthYear} 年，今年 ${currentYear - birthYear} 岁</p>
            <p class="debug-info" style="color: #666; font-size: 0.9em;">
                改革开放总年数: ${totalReformYears}年 | 您经历: ${personalReformYears}年
            </p>
        </div>
        
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number">${personalReformYears}</div>
                <div class="stat-label">亲历改革开放年限</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">${lifePercentage}%</div>
                <div class="stat-label">人生与改革开放重叠度</div>
                <div style="font-size: 0.8em; margin-top: 5px;">占改革开放进程的${lifePercentage}%</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">${calculateGDPGrowth(birthYear)}</div>
                <div class="stat-label">期间GDP增长倍数</div>
            </div>
        </div>

        <div class="analysis-section">
            <h4>个人成长分析</h4>
            <p>${analysis}</p>
        </div>

        <div class="milestones-section">
            <h4>您的人生关键节点</h4>
            <div class="milestones-list">${milestones}</div>
        </div>

        <div class="comparison-section">
            <h4>经济发展对比</h4>
            <div class="comparison-content">${comparison}</div>
        </div>

        <div class="personal-timeline">
            <h4>您的个人改革开放时间轴</h4>
            <div class="timeline">${generatePersonalTimeline(birthYear)}</div>
        </div>
    `;
}

    function generatePersonalAnalysis(birthYear, ageAtReformStart, reformYears) {
        if (birthYear < 1978) {
            return `您比改革开放年长 ${Math.abs(ageAtReformStart)} 岁，是改革开放的见证者和参与者。您亲眼目睹了中国从计划经济向市场经济的转型，经历了物质生活从匮乏到丰富的全过程。`;
        } else if (birthYear === 1978) {
            return `您与改革开放同龄！您的成长历程就是改革开放的发展史，每一个重要节点都与您的人生阶段紧密相连。`;
        } else if (birthYear < 1990) {
            return `您在改革开放初期出生，成长过程伴随着中国的快速发展和深刻变革。您经历了市场经济体制的建立和完善，是改革开放成果的直接受益者。`;
        } else if (birthYear < 2000) {
            return `您在改革开放深化阶段出生，成长于中国加入WTO、经济全球化的时代。您见证了互联网的普及和数字经济的崛起。`;
        } else {
            return `您在新世纪出生，是改革开放的"成果一代"。您成长在中国特色社会主义新时代，享受着改革开放带来的繁荣与便利。`;
        }
    }

    function generatePersonalMilestones(birthYear) {
        const milestones = [];
        const currentYear = new Date().getFullYear();
        
        // 根据年龄添加重要人生节点
        const ages = [
            { age: 0, event: "您出生了，来到改革开放的中国" },
            { age: 6, event: "开始上小学，接受义务教育" },
            { age: 18, event: "成年，具备完全民事行为能力" },
            { age: 22, event: "大学毕业，进入社会" }
        ];

        ages.forEach(({ age, event }) => {
            const milestoneYear = birthYear + age;
            if (milestoneYear <= currentYear) {
                const reformAge = milestoneYear - 1978;
                milestones.push(`
                    <div class="milestone">
                        <span class="milestone-year">${milestoneYear}年</span>
                        <span class="milestone-event">${event}（改革开放第${reformAge}年）</span>
                    </div>
                `);
            }
        });

        return milestones.join('');
    }

    function generateEconomicComparison(birthYear) {
        const gdpData = {
            "1978": 3679,
            "1980": 4588,
            "1985": 9099,
            "1990": 18873,
            "1995": 61340,
            "2000": 100280,
            "2005": 187319,
            "2010": 412119,
            "2015": 688858,
            "2020": 1015986,
            "2023": 1260582
        };

        // 找到最接近出生年份的GDP数据
        let birthGDP;
        if (birthYear <= 1978) {
            birthGDP = gdpData["1978"];
        } else {
            // 找到小于等于出生年份的最大年份
            const availableYears = Object.keys(gdpData).map(Number).sort((a, b) => a - b);
            let closestYear = 1978;
            for (let year of availableYears) {
                if (year <= birthYear) {
                    closestYear = year;
                } else {
                    break;
                }
            }
            birthGDP = gdpData[closestYear.toString()];
        }

        const currentGDP = gdpData["2023"];
        const growthTimes = (currentGDP / birthGDP).toFixed(1);
        const yearsDiff = 2023 - (birthYear <= 1978 ? 1978 : birthYear);

        return `
            <div class="economic-stats">
                <p>从您${birthYear <= 1978 ? '改革开放开始' : '出生'}至今，中国GDP从 <strong>${(birthGDP / 10000).toFixed(1)}万亿元</strong> 增长到 <strong>${(currentGDP / 10000).toFixed(1)}万亿元</strong></p>
                <p>经济增长了 <strong>${growthTimes}倍</strong>，年均增长率约 <strong>${yearsDiff > 0 ? ((Math.pow(growthTimes, 1/yearsDiff)-1)*100).toFixed(1) : 0}%</strong></p>
            </div>
        `;
    }

    function calculateGDPGrowth(birthYear) {
        const gdpData = {
            "1978": 3679,
            "1980": 4588,
            "1985": 9099,
            "1990": 18873,
            "1995": 61340,
            "2000": 100280,
            "2005": 187319,
            "2010": 412119,
            "2015": 688858,
            "2020": 1015986,
            "2023": 1260582
        };

        // 找到最接近出生年份的GDP数据
        let birthGDP;
        if (birthYear <= 1978) {
            birthGDP = gdpData["1978"];
        } else {
            const availableYears = Object.keys(gdpData).map(Number).sort((a, b) => a - b);
            let closestYear = 1978;
            for (let year of availableYears) {
                if (year <= birthYear) {
                    closestYear = year;
                } else {
                    break;
                }
            }
            birthGDP = gdpData[closestYear.toString()];
        }

        const currentGDP = gdpData["2023"];
        return (currentGDP / birthGDP).toFixed(0);
    }

    function generatePersonalTimeline(birthYear) {
        const personalEvents = [];
        const currentYear = new Date().getFullYear();
        
        for (let year = Math.max(birthYear, 1978); year <= currentYear; year++) {
            const reformEvent = timelineData.find(item => item.year === year.toString());
            if (reformEvent) {
                const personalAge = year - birthYear;
                personalEvents.push(`
                    <div class="personal-event">
                        <div class="event-year">${year}年</div>
                        <div class="event-content">
                            <strong>${reformEvent.title}</strong>
                            <p>${reformEvent.content}</p>
                            <small>此时您${personalAge >= 0 ? personalAge : '尚未出生'}岁</small>
                        </div>
                    </div>
                `);
            }
        }

        return personalEvents.length > 0 ? personalEvents.join('') : '<p>在您的人生历程中，暂无对应的改革开放重大事件。</p>';
    }
}

// 为计算器添加样式
function addCalculatorStyles() {
    const style = document.createElement('style');
    style.textContent = `
        .calculator-container {
            margin: 50px 0;
            padding: 30px;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        .calculator-container h2 {
            color: #c8161d;
            text-align: center;
            margin-bottom: 30px;
            font-size: 1.8em;
        }

        .calculator-form {
            max-width: 400px;
            margin: 0 auto 30px;
            text-align: center;
        }

        .input-group {
            margin-bottom: 20px;
        }

        .input-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #333;
        }

        #birth-year {
            width: 200px;
            padding: 12px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 1.1em;
            text-align: center;
        }

        #birth-year:focus {
            border-color: #c8161d;
            outline: none;
        }

        #calculate-btn {
            background: linear-gradient(45deg, #c8161d, #e74c3c);
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 25px;
            font-size: 1.1em;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        #calculate-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(199, 22, 29, 0.3);
        }

        .calculator-results {
            background: white;
            border-radius: 10px;
            padding: 30px;
            margin-top: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .results-header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #f0f0f0;
            padding-bottom: 20px;
        }

        .results-header h3 {
            color: #c8161d;
            margin-bottom: 10px;
        }

        .user-age {
            font-size: 1.1em;
            color: #666;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }

        .stat-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
        }

        .stat-number {
            font-size: 2em;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .stat-label {
            font-size: 0.9em;
            opacity: 0.9;
        }

        .analysis-section,
        .milestones-section,
        .comparison-section,
        .personal-timeline {
            margin: 30px 0;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 8px;
        }

        .analysis-section h4,
        .milestones-section h4,
        .comparison-section h4,
        .personal-timeline h4 {
            color: #c8161d;
            margin-bottom: 15px;
            border-left: 4px solid #c8161d;
            padding-left: 10px;
        }

        .milestone {
            display: flex;
            align-items: center;
            margin: 10px 0;
            padding: 10px;
            background: white;
            border-radius: 5px;
            border-left: 3px solid #4cd964;
        }

        .milestone-year {
            font-weight: bold;
            color: #c8161d;
            min-width: 80px;
        }

        .economic-stats {
            background: white;
            padding: 15px;
            border-radius: 5px;
            border: 1px solid #e0e0e0;
        }

        .personal-event {
            display: flex;
            margin: 15px 0;
            padding: 15px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .event-year {
            font-weight: bold;
            color: #c8161d;
            min-width: 80px;
            margin-right: 15px;
        }

        .event-content small {
            color: #666;
            font-style: italic;
        }

        .error {
            color: #e74c3c;
            text-align: center;
            padding: 10px;
            background: #ffeaea;
            border-radius: 5px;
        }

        @media (max-width: 768px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .personal-event {
                flex-direction: column;
            }
            
            .event-year {
                margin-bottom: 10px;
            }
        }
    `;
    document.head.appendChild(style);
}
// 新增功能：国际视角 - 展示国际社会对中国改革开放的评价和反应
function addInternationalPerspective() {
    // 创建国际视角数据
    const internationalPerspectives = [
        {
            period: "1978-1984年 改革开放初期",
            quotes: [
                {
                    source: "美国《时代》周刊",
                    content: "中国的改革是20世纪最重大的历史事件之一，邓小平引领中国从封闭走向开放。",
                    year: "1979年"
                },
                {
                    source: "英国《金融时报》",
                    content: "家庭联产承包责任制释放了中国农民的生产积极性，为中国经济腾飞奠定了基础。",
                    year: "1983年"
                },
                {
                    source: "世界银行报告",
                    content: "中国的农村改革模式值得其他发展中国家学习，它成功解决了亿万人的温饱问题。",
                    year: "1984年"
                }
            ],
            reaction: "国际社会最初对中国改革开放持谨慎观察态度，但随着农村改革取得显著成效，开始给予积极评价。"
        },
        {
            period: "1984-1992年 城市改革与沿海开放",
            quotes: [
                {
                    source: "美国前国务卿基辛格",
                    content: "中国设立经济特区的决策展现了非凡的战略眼光，将成为中国与世界经济融合的桥梁。",
                    year: "1985年"
                },
                {
                    source: "日本《读卖新闻》",
                    content: "中国的改革开放为日本企业提供了巨大的市场机遇，中日经济合作进入新阶段。",
                    year: "1988年"
                },
                {
                    source: "联合国开发计划署",
                    content: "中国的发展模式为全球减贫事业作出了突出贡献，10年间帮助数亿人摆脱贫困。",
                    year: "1991年"
                }
            ],
            reaction: "国际社会对中国改革开放的关注度显著提高，多国企业开始进入中国市场，投资合作不断深化。"
        },
        {
            period: "1992-2001年 社会主义市场经济体制建立",
            quotes: [
                {
                    source: "美国前总统克林顿",
                    content: "中国确立社会主义市场经济体制是具有历史意义的决策，将进一步推动中国融入全球经济。",
                    year: "1993年"
                },
                {
                    source: "欧盟委员会",
                    content: "中国经济的持续高速增长为全球经济注入了新活力，欧盟愿与中国加强经贸合作。",
                    year: "1998年"
                },
                {
                    source: "诺贝尔经济学奖得主斯蒂格利茨",
                    content: "中国的改革路径不同于西方模式，但其成功证明了发展道路的多样性。",
                    year: "2000年"
                }
            ],
            reaction: "国际社会对中国改革开放的评价更加积极，中国经济的快速发展成为全球经济增长的重要引擎。"
        },
        {
            period: "2001-2012年 加入WTO与全面开放",
            quotes: [
                {
                    source: "世界贸易组织总干事素帕猜",
                    content: "中国加入WTO是多边贸易体制发展的重要里程碑，将为全球贸易增长带来新机遇。",
                    year: "2001年"
                },
                {
                    source: "《经济学人》杂志",
                    content: "中国已成为世界工厂，中国制造改变了全球供应链格局。",
                    year: "2005年"
                },
                {
                    source: "国际货币基金组织",
                    content: "中国经济总量跃居世界第二，在全球经济治理中的地位和作用日益提升。",
                    year: "2011年"
                }
            ],
            reaction: "中国加入WTO后，国际社会高度关注中国在全球经济中的角色转变，中国与世界的相互依存度显著提高。"
        },
        {
            period: "2012年至今 新时代改革开放",
            quotes: [
                {
                    source: "联合国秘书长古特雷斯",
                    content: "中国提出的'一带一路'倡议为全球发展合作提供了新平台，有助于实现共同繁荣。",
                    year: "2017年"
                },
                {
                    source: "世界银行行长马尔帕斯",
                    content: "中国在减贫方面取得的成就史无前例，为其他发展中国家提供了宝贵经验。",
                    year: "2020年"
                },
                {
                    source: "《财富》全球论坛",
                    content: "中国持续推进高水平对外开放，为全球企业创造了更多发展机遇。",
                    year: "2023年"
                }
            ],
            reaction: "国际社会高度评价中国在新时代的改革开放成就，中国提出的全球治理理念和倡议得到广泛响应。"
        }
    ];

    // 创建国际视角容器
    const timeline = document.querySelector('.timeline');
    const perspectiveContainer = document.createElement('div');
    perspectiveContainer.className = 'international-perspective';
    perspectiveContainer.innerHTML = `
        <div class="perspective-header">
            <h2>国际视角</h2>
            <p>国际社会对中国改革开放的评价和反应</p>
        </div>
        <div class="perspective-content">
            <div class="perspective-tabs">
                ${internationalPerspectives.map((item, index) => `
                    <button class="perspective-tab ${index === 0 ? 'active' : ''}" data-index="${index}">${item.period.split(' ')[0]}</button>
                `).join('')}
            </div>
            <div class="perspective-panels">
                ${internationalPerspectives.map((item, index) => `
                    <div class="perspective-panel ${index === 0 ? 'active' : ''}" data-index="${index}">
                        <div class="quotes-section">
                            ${item.quotes.map(quote => `
                                <div class="quote-card">
                                    <div class="quote-text">"${quote.content}"</div>
                                    <div class="quote-source">— ${quote.source}（${quote.year}）</div>
                                </div>
                            `).join('')}
                        </div>
                        <div class="reaction-section">
                            <h4>国际社会反应</h4>
                            <p>${item.reaction}</p>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;

    // 在时间轴后添加国际视角模块
    timeline.after(perspectiveContainer);

    // 添加交互逻辑
    const tabs = document.querySelectorAll('.perspective-tab');
    const panels = document.querySelectorAll('.perspective-panel');

    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const index = tab.getAttribute('data-index');
            
            // 切换标签激活状态
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            
            // 切换面板显示
            panels.forEach(panel => {
                panel.classList.remove('active');
                if (panel.getAttribute('data-index') === index) {
                    panel.classList.add('active');
                }
            });
        });
    });

    console.log('国际视角功能已添加');
}

// 为国际视角添加样式
function addInternationalPerspectiveStyles() {
    const style = document.createElement('style');
    style.textContent = `
        .international-perspective {
            margin: 50px 0;
            padding: 30px;
            background: linear-gradient(135deg, #f0f9ff 0%, #e6f7ff 100%);
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        .perspective-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .perspective-header h2 {
            color: #c8161d;
            margin-bottom: 10px;
            font-size: 1.8em;
        }

        .perspective-header p {
            color: #666;
            font-size: 1.1em;
        }

        .perspective-tabs {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            justify-content: center;
            margin-bottom: 30px;
        }

        .perspective-tab {
            padding: 12px 20px;
            background-color: #fff;
            color: #333;
            border: 2px solid #ddd;
            border-radius: 25px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 1em;
            font-weight: bold;
        }

        .perspective-tab:hover {
            background-color: #f8f9fa;
            border-color: #c8161d;
            transform: translateY(-2px);
        }

        .perspective-tab.active {
            background-color: #c8161d;
            color: white;
            border-color: #c8161d;
        }

        .perspective-panel {
            display: none;
        }

        .perspective-panel.active {
            display: block;
            animation: fadeIn 0.5s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .quotes-section {
            margin-bottom: 30px;
        }

        .quote-card {
            background: white;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            position: relative;
            padding-left: 40px;
        }

        .quote-card::before {
            content: '"';
            position: absolute;
            left: 15px;
            top: 10px;
            font-size: 48px;
            color: #c8161d;
            opacity: 0.2;
            font-family: Georgia, serif;
        }

        .quote-text {
            font-size: 1.1em;
            line-height: 1.6;
            color: #333;
            margin-bottom: 10px;
        }

        .quote-source {
            font-style: italic;
            color: #666;
            text-align: right;
        }

        .reaction-section {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }

        .reaction-section h4 {
            color: #c8161d;
            margin-bottom: 15px;
            font-size: 1.3em;
        }

        .reaction-section p {
            line-height: 1.6;
            color: #333;
        }

        /* 暗黑模式适配 */
        .dark-mode .international-perspective {
            background: linear-gradient(135deg, #1a202c 0%, #2d3748 100%);
        }

        .dark-mode .perspective-header p {
            color: #a0aec0;
        }

        .dark-mode .perspective-tab {
            background-color: #2d3748;
            color: #e2e8f0;
            border-color: #4a5568;
        }

        .dark-mode .perspective-tab:hover {
            background-color: #4a5568;
            border-color: #fbb6ce;
        }

        .dark-mode .quote-card,
        .dark-mode .reaction-section {
            background-color: #2d3748;
            color: #e2e8f0;
        }

        .dark-mode .quote-text,
        .dark-mode .reaction-section p {
            color: #e2e8f0;
        }

        .dark-mode .quote-source {
            color: #a0aec0;
        }

        /* 响应式设计 */
        @media (max-width: 768px) {
            .perspective-tabs {
                flex-direction: column;
                align-items: center;
            }

            .perspective-tab {
                width: 100%;
                max-width: 300px;
            }

            .quote-card {
                padding-left: 20px;
            }

            .quote-card::before {
                left: 5px;
                font-size: 36px;
            }
        }
    `;
    document.head.appendChild(style);
}

window.addEventListener('load', () => {
    console.log('正在初始化新增功能...');
    
    // 原有的功能初始化...
    try {
        addSearchFunction();
        console.log('搜索功能已添加');
    } catch (e) {
        console.error('搜索功能初始化失败:', e);
    }
    
    try {
        addYearNavigation();
        console.log('年份导航已添加');
    } catch (e) {
        console.error('年份导航初始化失败:', e);
    }
    
    try {
        addQuizExplanations();
        console.log('答题解析功能已添加');
    } catch (e) {
        console.error('答题解析功能初始化失败:', e);
    }
    
    try {
        addDarkMode();
        console.log('暗黑模式已添加');
    } catch (e) {
        console.error('暗黑模式初始化失败:', e);
    }
    
    try {
        addEnhancementStyles();
        console.log('增强样式已添加');
    } catch (e) {
        console.error('增强样式初始化失败:', e);
    }
    
    enhanceDarkModeForGDP();
    
    // 新增的计算器功能
    try {
        addReformCalculator();
        addCalculatorStyles();
        console.log('改革开放成就计算器已添加');
    } catch (e) {
        console.error('计算器功能初始化失败:', e);
    }
    
    // 新增的国际视角功能
    try {
        addInternationalPerspective();
        addInternationalPerspectiveStyles();
        console.log('国际视角功能已添加');
    } catch (e) {
        console.error('国际视角功能初始化失败:', e);
    }
    
    // 新增的改革先锋人物功能
    try {
        addReformPioneers();
        addReformPioneersStyles();
        console.log('改革先锋人物功能已添加');
    } catch (e) {
        console.error('改革先锋人物功能初始化失败:', e);
    }
    
    // 新增的改革开放45周年特别内容
    try {
        addReform45thAnniversary();
        addReform45thAnniversaryStyles();
        console.log('改革开放45周年特别内容已添加');
    } catch (e) {
        console.error('改革开放45周年特别内容初始化失败:', e);
    }
    
    console.log('所有功能初始化完成');
});

// 新增功能：改革开放45周年特别内容 - 2023年以来的最新发展内容
function addReform45thAnniversary() {
    // 创建改革开放45周年数据
    const anniversaryContent = {
        title: "改革开放45周年特别内容",
        subtitle: "2023年以来的最新发展",
        sections: [
            {
                id: "economic-updates",
                title: "经济发展新成就",
                icon: "📈",
                content: [
                    "2023年，中国国内生产总值突破126万亿元，同比增长5.2%，经济总量稳居世界第二。",
                    "科技创新驱动发展战略深入实施，全社会研发经费投入强度达到2.55%，国家创新能力综合排名上升至世界第10位。",
                    "数字经济蓬勃发展，规模达到50.2万亿元，占GDP比重超过41%。",
                    "高质量共建'一带一路'取得新成效，截至2023年底，中国已与152个国家、32个国际组织签署200余份共建'一带一路'合作文件。"
                ]
            },
            {
                id: "tech-innovation",
                title: "科技创新新突破",
                icon: "🚀",
                content: [
                    "人工智能领域取得重大进展，大模型技术实现从'跟跑'到'并跑'再到部分'领跑'的转变。",
                    "量子计算研究实现突破，'九章三号'量子计算原型机实现量子优势。",
                    "中国空间站全面建成并投入运营，'嫦娥'探月工程、'天问'火星探测、'天宫'空间站等重大航天工程取得一系列标志性成果。",
                    "新能源技术快速发展，2023年中国新能源汽车产销量分别达到958.7万辆和949.5万辆，同比分别增长35.8%和37.9%，连续9年位居全球第一。"
                ]
            },
            {
                id: "green-development",
                title: "绿色发展新进展",
                icon: "🌱",
                content: [
                    "生态文明建设持续推进，2023年单位GDP能耗同比下降3.1%，主要污染物排放量继续下降。",
                    "碳达峰碳中和工作稳步推进，全国碳排放权交易市场累计成交额突破1000亿元。",
                    "森林覆盖率达到24.02%，森林蓄积量达到194.93亿立方米，成为全球森林资源增长最多的国家。",
                    "可再生能源发展迅猛，截至2023年底，中国可再生能源装机容量突破13亿千瓦，占全国发电总装机容量的48.8%。"
                ]
            },
            {
                id: "people-livelihood",
                title: "民生改善新成果",
                icon: "👪",
                content: [
                    "脱贫攻坚成果持续巩固拓展，防止返贫监测帮扶机制不断完善，农村居民人均可支配收入实际增长6.3%。",
                    "就业形势总体稳定，2023年城镇新增就业1244万人，超额完成全年目标任务。",
                    "社会保障体系不断完善，基本养老保险覆盖10.5亿人，基本医疗保险覆盖13.6亿人。",
                    "教育、医疗、养老等公共服务水平不断提升，人民群众的获得感、幸福感、安全感持续增强。"
                ]
            },
            {
                id: "global-cooperation",
                title: "全球合作新篇章",
                icon: "🌐",
                content: [
                    "中国积极参与全球治理体系改革和建设，提出全球发展倡议、全球安全倡议、全球文明倡议，为解决人类面临的共同问题提供中国方案。",
                    "中国-东盟全面战略伙伴关系深入发展，区域全面经济伙伴关系协定（RCEP）生效实施，为区域经济一体化注入新动力。",
                    "金砖国家合作机制不断深化，金砖扩员进程启动，影响力持续提升。",
                    "中国坚定支持多边贸易体制，积极参与世界贸易组织改革，推动建设开放型世界经济。"
                ]
            }
        ]
    };

    // 创建改革开放45周年特别内容容器
    const pioneersContainer = document.querySelector('.reform-pioneers');
    const anniversaryContainer = document.createElement('div');
    anniversaryContainer.className = 'reform-45th-anniversary';
    
    // 生成内容HTML
    const sectionsHTML = anniversaryContent.sections.map(section => `
        <div class="anniversary-section" data-id="${section.id}">
            <div class="section-header">
                <span class="section-icon">${section.icon}</span>
                <h3>${section.title}</h3>
            </div>
            <div class="section-content">
                <ul>
                    ${section.content.map(item => `<li>${item}</li>`).join('')}
                </ul>
            </div>
        </div>
    `).join('');
    
    anniversaryContainer.innerHTML = `
        <div class="anniversary-header">
            <div class="anniversary-badge">
                <span>特别纪念</span>
            </div>
            <h2>${anniversaryContent.title}</h2>
            <p>${anniversaryContent.subtitle}</p>
        </div>
        <div class="anniversary-grid">
            ${sectionsHTML}
        </div>
        <div class="anniversary-timeline">
            <div class="timeline-header">
                <h4>45周年发展脉络</h4>
            </div>
            <div class="timeline-items">
                <div class="timeline-item">
                    <div class="timeline-year">1978</div>
                    <div class="timeline-content">
                        <h5>伟大转折</h5>
                        <p>党的十一届三中全会召开，作出实行改革开放的历史性决策。</p>
                    </div>
                </div>
                <div class="timeline-item">
                    <div class="timeline-year">1992</div>
                    <div class="timeline-content">
                        <h5>加快步伐</h5>
                        <p>邓小平南方谈话，党的十四大确立社会主义市场经济体制改革目标。</p>
                    </div>
                </div>
                <div class="timeline-item">
                    <div class="timeline-year">2001</div>
                    <div class="timeline-content">
                        <h5>融入世界</h5>
                        <p>中国加入世界贸易组织，对外开放进入新阶段。</p>
                    </div>
                </div>
                <div class="timeline-item">
                    <div class="timeline-year">2012</div>
                    <div class="timeline-content">
                        <h5>全面深化</h5>
                        <p>党的十八大召开，改革开放进入新时代。</p>
                    </div>
                </div>
                <div class="timeline-item">
                    <div class="timeline-year">2023</div>
                    <div class="timeline-content">
                        <h5>45周年</h5>
                        <p>改革开放45周年，中国特色社会主义进入新时代新征程。</p>
                    </div>
                </div>
            </div>
        </div>
    `;

    // 在改革先锋人物后添加改革开放45周年特别内容模块
    pioneersContainer.after(anniversaryContainer);

    // 添加交互效果
    const anniversarySections = document.querySelectorAll('.anniversary-section');
    anniversarySections.forEach(section => {
        section.addEventListener('mouseenter', () => {
            section.classList.add('section-hover');
        });
        section.addEventListener('mouseleave', () => {
            section.classList.remove('section-hover');
        });
    });

    console.log('改革开放45周年特别内容已添加');
}

// 为改革开放45周年特别内容添加样式
function addReform45thAnniversaryStyles() {
    const style = document.createElement('style');
    style.textContent = `
        .reform-45th-anniversary {
            margin: 50px 0;
            padding: 30px;
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            position: relative;
            overflow: hidden;
        }

        .reform-45th-anniversary::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(59, 130, 246, 0.1) 0%, transparent 70%);
            z-index: 0;
        }

        .anniversary-header {
            text-align: center;
            margin-bottom: 40px;
            position: relative;
            z-index: 1;
        }

        .anniversary-badge {
            display: inline-block;
            background: linear-gradient(45deg, #3b82f6, #0ea5e9);
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.9em;
            margin-bottom: 15px;
            box-shadow: 0 3px 10px rgba(59, 130, 246, 0.3);
        }

        .anniversary-header h2 {
            color: #1e40af;
            margin-bottom: 10px;
            font-size: 1.8em;
        }

        .anniversary-header p {
            color: #64748b;
            font-size: 1.1em;
        }

        .anniversary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 25px;
            margin-bottom: 50px;
            position: relative;
            z-index: 1;
        }

        .anniversary-section {
            background: white;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            border: 2px solid transparent;
            position: relative;
            overflow: hidden;
        }

        .anniversary-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: linear-gradient(90deg, #3b82f6, #0ea5e9);
            transform: scaleX(0);
            transition: transform 0.3s ease;
        }

        .anniversary-section.section-hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
            border-color: #3b82f6;
        }

        .anniversary-section.section-hover::before {
            transform: scaleX(1);
        }

        .section-header {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }

        .section-icon {
            font-size: 1.8em;
            margin-right: 15px;
        }

        .section-header h3 {
            color: #1e40af;
            font-size: 1.3em;
            margin: 0;
        }

        .section-content ul {
            list-style-type: none;
            padding: 0;
        }

        .section-content li {
            margin-bottom: 12px;
            padding-left: 25px;
            position: relative;
            line-height: 1.6;
            color: #334155;
        }

        .section-content li::before {
            content: '➤';
            position: absolute;
            left: 0;
            color: #3b82f6;
            font-weight: bold;
        }

        /* 45周年时间线样式 */
        .anniversary-timeline {
            background: white;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            position: relative;
            z-index: 1;
        }

        .timeline-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .timeline-header h4 {
            color: #1e40af;
            font-size: 1.5em;
            margin: 0;
        }

        .timeline-items {
            position: relative;
            padding-left: 30px;
        }

        .timeline-items::before {
            content: '';
            position: absolute;
            left: 15px;
            top: 0;
            bottom: 0;
            width: 2px;
            background: linear-gradient(to bottom, #3b82f6, #0ea5e9);
        }

        .timeline-item {
            position: relative;
            margin-bottom: 25px;
            padding-left: 30px;
        }

        .timeline-item::before {
            display: none;
        }

        .timeline-year {
            font-weight: bold;
            color: #c8161d;
            margin-bottom: 5px;
            font-size: 1.1em;
        }

        .timeline-content h5 {
            color: #1e40af;
            margin-bottom: 8px;
            font-size: 1.1em;
        }

        .timeline-content p {
            color: #64748b;
            line-height: 1.5;
            margin: 0;
        }

        /* 暗黑模式适配 */
        .dark-mode .reform-45th-anniversary {
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
        }

        .dark-mode .anniversary-header p,
        .dark-mode .timeline-content p {
            color: #94a3b8;
        }

        .dark-mode .anniversary-section,
        .dark-mode .anniversary-timeline {
            background-color: #1e293b;
            color: #f1f5f9;
        }

        .dark-mode .section-header h3,
        .dark-mode .timeline-header h4,
        .dark-mode .timeline-content h5 {
            color: #93c5fd;
        }
        
        /* 确保暗黑模式下年代字体颜色也是红色 */
        .dark-mode .timeline-year {
            color: #c8161d;
        }

        .dark-mode .section-content li {
            color: #f1f5f9;
        }

        /* 响应式设计 */
        @media (max-width: 768px) {
            .anniversary-grid {
                grid-template-columns: 1fr;
            }

            .anniversary-header h2 {
                font-size: 1.5em;
            }

            .section-header {
                flex-direction: column;
                text-align: center;
            }

            .section-icon {
                margin-right: 0;
                margin-bottom: 10px;
            }

            .timeline-items {
                padding-left: 20px;
            }

            .timeline-items::before {
                left: 10px;
            }

            .timeline-item::before {
                left: -20px;
            }
        }
    `;
    document.head.appendChild(style);
}

// 新增功能：改革先锋人物 - 介绍为改革开放做出突出贡献的人物事迹
function addReformPioneers() {
    // 创建改革先锋人物数据
    const reformPioneers = [
        {
            id: 1,
            name: "邓小平",
            period: "1904-1997",
            title: "改革开放总设计师",
            contributions: [
                "提出'解放思想，实事求是'的思想路线",
                "推动家庭联产承包责任制改革",
                "倡导设立经济特区，推动对外开放",
                "提出'一国两制'伟大构想",
                "南方谈话推动改革开放进入新阶段"
            ],
            story: "邓小平是中国改革开放和社会主义现代化建设的总设计师。他倡导的'实践是检验真理的唯一标准'大讨论，为改革开放奠定了思想基础。1978年，他推动党的十一届三中全会作出把党和国家工作中心转移到经济建设上来、实行改革开放的历史性决策。在他的领导下，中国走上了建设中国特色社会主义的正确道路。"
        },
        {
            id: 2,
            name: "袁隆平",
            period: "1930-2021",
            title: "杂交水稻之父",
            contributions: [
                "成功培育出高产杂交水稻品种",
                "解决了中国乃至世界的粮食安全问题",
                "推动杂交水稻技术走向世界",
                "荣获国家最高科学技术奖和世界粮食奖"
            ],
            story: "袁隆平是中国杂交水稻育种专家，被誉为'杂交水稻之父'。他一生致力于杂交水稻技术的研究、应用与推广，发明'三系法'籼型杂交水稻，成功研究出'两系法'杂交水稻，创建了超级杂交稻技术体系，为中国粮食安全、农业科学发展和世界粮食供给作出了杰出贡献。"
        },
        {
            id: 3,
            name: "吴仁宝",
            period: "1928-2013",
            title: "华西村改革带头人",
            contributions: [
                "带领华西村从贫困村发展成为'天下第一村'",
                "探索农村集体企业发展道路",
                "推动农村工业化和城镇化进程",
                "创立'华西经验'，为农村改革提供范例"
            ],
            story: "吴仁宝是江苏省江阴市华西村原党委书记，他带领华西村村民经过几十年的艰苦奋斗，将一个贫穷落后的小村庄建设成为闻名全国的'天下第一村'。华西村的发展模式，为中国农村改革和现代化建设提供了宝贵经验。"
        },
        {
            id: 4,
            name: "任正非",
            period: "1944-至今",
            title: "华为创始人",
            contributions: [
                "创立华为技术有限公司",
                "推动中国通信技术从跟随到引领",
                "带领华为成为全球领先的信息与通信技术解决方案供应商",
                "推动科技创新和人才培养"
            ],
            story: "任正非是华为技术有限公司主要创始人兼总裁。在他的领导下，华为从一家小型通信设备代理商发展成为全球领先的信息与通信技术解决方案供应商。华为的发展历程，是中国高科技企业自主创新、走向世界的典型代表。"
        },
        {
            id: 5,
            name: "马云",
            period: "1964-至今",
            title: "阿里巴巴集团创始人",
            contributions: [
                "创立阿里巴巴集团",
                "推动中国电子商务发展",
                "创建淘宝、支付宝等改变中国人生活方式的平台",
                "积极参与全球数字经济合作"
            ],
            story: "马云是阿里巴巴集团主要创始人。他带领团队创立的阿里巴巴、淘宝、支付宝等平台，彻底改变了中国人的购物和支付方式，推动了中国电子商务的蓬勃发展。阿里巴巴的成功，展示了中国互联网企业的创新活力和全球化视野。"
        },
        {
            id: 6,
            name: "孙家栋",
            period: "1929-至今",
            title: "中国航天工程总设计师",
            contributions: [
                "主持研制中国第一颗人造地球卫星",
                "担任中国探月工程总设计师",
                "推动中国航天事业从无到有、从小到大",
                "荣获'两弹一星'功勋奖章和国家最高科学技术奖"
            ],
            story: "孙家栋是中国航天科技集团有限公司高级技术顾问，他是中国航天事业的亲历者、见证者和领导者。从第一颗人造地球卫星到北斗导航系统，从探月工程到深空探测，孙家栋为中国航天事业的发展作出了卓越贡献。"
        }
    ];

    // 创建改革先锋人物容器
    const perspectiveContainer = document.querySelector('.international-perspective');
    const pioneersContainer = document.createElement('div');
    pioneersContainer.className = 'reform-pioneers';
    pioneersContainer.innerHTML = `
        <div class="pioneers-header">
            <h2>改革先锋人物</h2>
            <p>为改革开放做出突出贡献的人物事迹</p>
        </div>
        <div class="pioneers-grid">
            ${reformPioneers.map(pioneer => `
                <div class="pioneer-card" data-id="${pioneer.id}">
                    <div class="pioneer-name">${pioneer.name}</div>
                    <div class="pioneer-period">${pioneer.period}</div>
                    <div class="pioneer-title">${pioneer.title}</div>
                    <button class="view-details">查看详情</button>
                </div>
            `).join('')}
        </div>
    `;

    // 在国际视角后添加改革先锋人物模块
    perspectiveContainer.after(pioneersContainer);

    // 创建详情弹窗
    const pioneersModal = document.createElement('div');
    pioneersModal.id = 'pioneers-modal';
    pioneersModal.className = 'modal';
    pioneersModal.innerHTML = `
        <div class="modal-content">
            <span class="modal-close">&times;</span>
            <div class="modal-body">
                <h3 id="modal-name"></h3>
                <div id="modal-period"></div>
                <div id="modal-title"></div>
                <div class="modal-contributions">
                    <h4>主要贡献</h4>
                    <ul id="modal-contributions-list"></ul>
                </div>
                <div class="modal-story">
                    <h4>人物事迹</h4>
                    <p id="modal-story-content"></p>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(pioneersModal);

    // 添加交互逻辑
    const pioneerCards = document.querySelectorAll('.pioneer-card');
    const modal = document.getElementById('pioneers-modal');
    const modalClose = document.querySelector('.modal-close');
    
    // 打开详情弹窗
    pioneerCards.forEach(card => {
        const viewDetailsBtn = card.querySelector('.view-details');
        viewDetailsBtn.addEventListener('click', () => {
            const pioneerId = parseInt(card.getAttribute('data-id'));
            const pioneer = reformPioneers.find(p => p.id === pioneerId);
            
            if (pioneer) {
                document.getElementById('modal-name').textContent = pioneer.name;
                document.getElementById('modal-period').textContent = pioneer.period;
                document.getElementById('modal-title').textContent = pioneer.title;
                
                const contributionsList = document.getElementById('modal-contributions-list');
                contributionsList.innerHTML = pioneer.contributions.map(contribution => 
                    `<li>${contribution}</li>`
                ).join('');
                
                document.getElementById('modal-story-content').textContent = pioneer.story;
                modal.style.display = 'block';
            }
        });
    });
    
    // 关闭详情弹窗
    modalClose.addEventListener('click', () => {
        modal.style.display = 'none';
    });
    
    // 点击弹窗外部关闭弹窗
    window.addEventListener('click', (event) => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });

    console.log('改革先锋人物功能已添加');
}

// 为改革先锋人物添加样式
function addReformPioneersStyles() {
    const style = document.createElement('style');
    style.textContent = `
        .reform-pioneers {
            margin: 50px 0;
            padding: 30px;
            background: linear-gradient(135deg, #fff5f7 0%, #ffebee 100%);
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        .pioneers-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .pioneers-header h2 {
            color: #c8161d;
            margin-bottom: 10px;
            font-size: 1.8em;
        }

        .pioneers-header p {
            color: #666;
            font-size: 1.1em;
        }

        .pioneers-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 20px;
            justify-items: center;
        }

        .pioneer-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            cursor: pointer;
            border: 2px solid transparent;
            width: 100%;
            max-width: 300px;
        }

        .pioneer-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
            border-color: #c8161d;
        }

        .pioneer-name {
            font-size: 1.5em;
            font-weight: bold;
            color: #c8161d;
            margin-bottom: 10px;
        }

        .pioneer-period {
            font-size: 0.9em;
            color: #666;
            margin-bottom: 15px;
        }

        .pioneer-title {
            font-size: 1.1em;
            color: #333;
            margin-bottom: 20px;
            padding: 8px 0;
            background-color: #f8f9fa;
            border-radius: 5px;
        }

        .view-details {
            background: linear-gradient(45deg, #c8161d, #e74c3c);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 20px;
            cursor: pointer;
            font-size: 0.9em;
            transition: all 0.3s ease;
        }

        .view-details:hover {
            transform: scale(1.05);
            box-shadow: 0 5px 15px rgba(199, 22, 29, 0.3);
        }

        /* 弹窗样式 */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.7);
        }

        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 30px;
            border-radius: 15px;
            width: 90%;
            max-width: 800px;
            box-shadow: 0 15px 40px rgba(0,0,0,0.3);
            animation: modalOpen 0.5s ease;
        }

        @keyframes modalOpen {
            from { opacity: 0; transform: translateY(-30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .modal-close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            transition: color 0.3s;
        }

        .modal-close:hover {
            color: #c8161d;
        }

        .modal-body {
            margin-top: 30px;
        }

        #modal-name {
            color: #c8161d;
            font-size: 1.8em;
            margin-bottom: 10px;
        }

        #modal-period {
            color: #666;
            font-size: 1em;
            margin-bottom: 15px;
        }

        #modal-title {
            color: #333;
            font-size: 1.2em;
            font-weight: bold;
            margin-bottom: 30px;
            padding: 10px 0;
            border-bottom: 2px solid #f0f0f0;
        }

        .modal-contributions h4,
        .modal-story h4 {
            color: #c8161d;
            margin: 25px 0 15px 0;
            font-size: 1.3em;
        }

        #modal-contributions-list {
            list-style-type: none;
            padding: 0;
        }

        #modal-contributions-list li {
            margin-bottom: 10px;
            padding-left: 25px;
            position: relative;
            line-height: 1.6;
            color: #333;
        }

        #modal-contributions-list li::before {
            content: '✓';
            position: absolute;
            left: 0;
            color: #c8161d;
            font-weight: bold;
        }

        #modal-story-content {
            line-height: 1.8;
            color: #333;
            text-align: justify;
        }

        /* 暗黑模式适配 */
        .dark-mode .reform-pioneers {
            background: linear-gradient(135deg, #1a202c 0%, #2d3748 100%);
        }

        .dark-mode .pioneers-header p {
            color: #a0aec0;
        }

        .dark-mode .pioneer-card {
            background-color: #2d3748;
            color: #e2e8f0;
        }

        .dark-mode .pioneer-title {
            background-color: #4a5568;
            color: #e2e8f0;
        }

        .dark-mode .modal-content {
            background-color: #2d3748;
            color: #e2e8f0;
        }

        .dark-mode #modal-period,
        .dark-mode #modal-contributions-list li,
        .dark-mode #modal-story-content {
            color: #e2e8f0;
        }

        .dark-mode #modal-title {
            border-bottom-color: #4a5568;
            color: #e2e8f0;
        }

        /* 响应式设计 */
        @media (max-width: 768px) {
            .pioneers-grid {
                grid-template-columns: 1fr;
            }

            .pioneer-card {
                max-width: none;
            }

            .modal-content {
                margin: 10% auto;
                padding: 20px;
            }

            #modal-name {
                font-size: 1.5em;
            }
        }
    `;
    document.head.appendChild(style);
}
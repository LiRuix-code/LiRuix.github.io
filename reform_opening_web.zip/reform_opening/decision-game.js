// 决策模拟游戏：让用户体验政策制定过程

// 游戏数据结构：不同历史时期的决策场景
const decisionScenarios = [
    {
        id: 'scenario-1',
        era: '1978-1984年',
        title: '农村改革的路径选择',
        background: '1978年，中国农村普遍存在着人民公社体制下的平均主义大锅饭问题，农民生产积极性不高，粮食产量增长缓慢。作为负责农村政策的决策者，你需要选择农村改革的方向。',
        options: [
            {
                id: 'option-1a',
                text: '坚持人民公社体制，加强集体化管理',
                result: {
                    shortTerm: '短期内维持了政策连续性，避免了社会震动',
                    longTerm: '但农民生产积极性持续低迷，粮食短缺问题难以解决，农村贫困状况没有明显改善。到1985年，全国仍有1.25亿农村人口处于贫困线以下。',
                    historicalImpact: '这与历史上的保守路线相似，实际上会延缓改革开放进程。',
                    gdpChange: -2
                }
            },
            {
                id: 'option-1b',
                text: '试点推行家庭联产承包责任制',
                result: {
                    shortTerm: '部分地区粮食产量显著提高，农民收入增加，生产积极性高涨',
                    longTerm: '承包制在全国推广，到1984年底，全国99%的生产队实行了家庭联产承包责任制，粮食产量从1978年的3.05亿吨增加到1984年的4.07亿吨。',
                    historicalImpact: '这与历史上的实际选择一致，成为中国农村改革的成功起点。',
                    gdpChange: 5
                }
            },
            {
                id: 'option-1c',
                text: '立即全面私有化改革',
                result: {
                    shortTerm: '引起社会剧烈震荡，部分地区出现土地兼并现象，农业生产秩序受到严重影响',
                    longTerm: '农村社会矛盾激化，贫富差距迅速扩大，政府失去对农业生产的宏观调控能力，粮食安全面临威胁。',
                    historicalImpact: '这超出了当时社会的承受能力，不符合渐进式改革的原则。',
                    gdpChange: -4
                }
            }
        ]
    },
    {
        id: 'scenario-2',
        era: '1984-1992年',
        title: '城市经济体制改革的突破口',
        background: '1984年，农村改革取得显著成效，但城市经济体制改革相对滞后。国有企业效率低下，缺乏活力，计划经济体制束缚了生产力的发展。作为城市改革的决策者，你需要选择改革的突破口。',
        options: [
            {
                id: 'option-2a',
                text: '重点改革价格体系，实行价格双轨制',
                result: {
                    shortTerm: '部分商品价格开始由市场调节，企业有了一定的自主定价权，市场活力初步显现',
                    longTerm: '但也出现了倒买倒卖、官倒等腐败现象，通货膨胀压力增大，1988年出现了严重的抢购风潮。',
                    historicalImpact: '这与历史上的实际选择相似，是价格改革的过渡阶段。',
                    gdpChange: 3
                }
            },
            {
                id: 'option-2b',
                text: '推进国有企业产权制度改革',
                result: {
                    shortTerm: '企业经营机制转换，部分国有企业开始扭亏为盈，职工积极性提高',
                    longTerm: '但改革过程中出现了国有资产流失问题，部分职工下岗失业，社会稳定面临挑战。',
                    historicalImpact: '这比历史上的实际改革步伐更快，风险也更大。',
                    gdpChange: 4
                }
            },
            {
                id: 'option-2c',
                text: '维持现有体制，加强宏观调控',
                result: {
                    shortTerm: '避免了改革可能带来的社会震荡，保持了经济的相对稳定',
                    longTerm: '但企业活力持续不足，经济效益下滑，与国际先进水平的差距进一步拉大。',
                    historicalImpact: '这与历史上的保守路线相似，会阻碍改革开放进程。',
                    gdpChange: -1
                }
            }
        ]
    },
    {
        id: 'scenario-3',
        era: '1992-2001年',
        title: '社会主义市场经济体制的建立',
        background: '1992年，邓小平南方谈话发表后，中国改革开放进入新阶段。计划与市场的关系成为改革的核心问题。作为经济体制改革的决策者，你需要明确改革的方向。',
        options: [
            {
                id: 'option-3a',
                text: '建立社会主义市场经济体制',
                result: {
                    shortTerm: '明确了改革方向，极大地解放了思想，调动了各方面的积极性，经济快速发展',
                    longTerm: '到2000年，中国GDP突破10万亿元，经济总量跃居世界第六位，初步建立了社会主义市场经济体制框架。',
                    historicalImpact: '这与历史上的实际选择一致，是改革开放的重要里程碑。',
                    gdpChange: 8
                }
            },
            {
                id: 'option-3b',
                text: '坚持计划经济为主，市场调节为辅',
                result: {
                    shortTerm: '保持了计划经济的主体地位，避免了市场化可能带来的风险',
                    longTerm: '但市场机制的作用受到限制，资源配置效率不高，经济增长动力不足。',
                    historicalImpact: '这与历史上的过渡性理论相似，但不符合生产力发展的要求。',
                    gdpChange: 2
                }
            },
            {
                id: 'option-3c',
                text: '完全照搬西方自由市场经济模式',
                result: {
                    shortTerm: '市场活力迅速释放，经济快速增长，但同时也带来了严重的贫富分化和社会问题',
                    longTerm: '政府调控能力减弱，经济波动加剧，社会保障体系不完善，社会矛盾激化。',
                    historicalImpact: '这不符合中国国情，会导致严重的经济和社会问题。',
                    gdpChange: 1
                }
            }
        ]
    },
    {
        id: 'scenario-4',
        era: '2001-2012年',
        title: '加入世界贸易组织后的战略选择',
        background: '2001年，中国正式加入世界贸易组织，对外开放进入新阶段。面对更加开放的国际环境和日益激烈的国际竞争，作为国家发展战略的决策者，你需要选择未来的发展路径。',
        options: [
            {
                id: 'option-4a',
                text: '积极参与经济全球化，扩大开放',
                result: {
                    shortTerm: '出口快速增长，外资大量涌入，经济保持高速增长',
                    longTerm: '到2010年，中国成为世界第二大经济体和第一大出口国，制造业规模跃居世界第一。但也面临着贸易摩擦增多、资源环境压力加大等问题。',
                    historicalImpact: '这与历史上的实际选择一致，是中国经济快速发展的重要动力。',
                    gdpChange: 7
                }
            },
            {
                id: 'option-4b',
                text: '加强产业保护，适度控制开放节奏',
                result: {
                    shortTerm: '保护了国内部分产业的发展，减少了国际经济波动的冲击',
                    longTerm: '但也错失了参与国际分工和产业升级的机遇，部分产业技术水平与国际先进水平的差距扩大。',
                    historicalImpact: '这是一种相对保守的选择，会延缓中国融入世界经济的进程。',
                    gdpChange: 3
                }
            },
            {
                id: 'option-4c',
                text: '重点发展高新技术产业，培育新动能',
                result: {
                    shortTerm: '科技投入增加，创新能力提升，高新技术产业快速发展',
                    longTerm: '在部分领域实现了技术突破和产业升级，但传统产业改造相对滞后，就业压力增大，区域发展不平衡问题加剧。',
                    historicalImpact: '这是一种前瞻性选择，但需要处理好与传统产业的关系。',
                    gdpChange: 5
                }
            }
        ]
    },
    {
        id: 'scenario-5',
        era: '2012年至今',
        title: '新时代的改革开放战略',
        background: '2012年以来，中国经济进入新常态，改革开放面临新形势、新任务。如何推动高质量发展，实现共同富裕，成为新时代改革开放的重要课题。作为新时代改革开放的决策者，你需要选择未来的发展方向。',
        options: [
            {
                id: 'option-5a',
                text: '深化供给侧结构性改革，推动经济高质量发展',
                result: {
                    shortTerm: '经济增长速度有所放缓，但质量效益不断提升，产业结构持续优化',
                    longTerm: '创新驱动发展战略深入实施，新动能不断壮大，经济发展韧性和活力显著增强。',
                    historicalImpact: '这与历史上的实际选择一致，是适应新时代要求的战略选择。',
                    gdpChange: 4
                }
            },
            {
                id: 'option-5b',
                text: '加大民生投入，促进共同富裕',
                result: {
                    shortTerm: '社会保障体系不断完善，居民收入增长较快，获得感、幸福感、安全感显著提升',
                    longTerm: '内需潜力持续释放，社会保持和谐稳定，为经济发展创造了良好环境。但也面临着财政压力增大、部分企业负担加重等问题。',
                    historicalImpact: '这是实现社会公平正义的重要举措，需要与经济发展相协调。',
                    gdpChange: 3
                }
            },
            {
                id: 'option-5c',
                text: '推进更高水平对外开放，构建新发展格局',
                result: {
                    shortTerm: '开放型经济新体制加快构建，外贸外资稳中提质，国际合作和竞争新优势不断增强',
                    longTerm: '国内国际双循环相互促进的新发展格局逐步形成，中国在全球经济治理中的话语权和影响力显著提升。',
                    historicalImpact: '这是应对百年未有之大变局的战略选择，为中国经济发展开辟了新空间。',
                    gdpChange: 5
                }
            }
        ]
    }
];

// 创建决策游戏容器
function createDecisionGame() {
    // 检查页面是否已加载完成
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initDecisionGame);
    } else {
        initDecisionGame();
    }
}

// 初始化决策游戏
function initDecisionGame() {
    // 创建游戏容器
    const footer = document.querySelector('footer');
    const gameContainer = document.createElement('div');
    gameContainer.id = 'decision-game';
    gameContainer.className = 'game-container';
    footer.before(gameContainer);

    // 添加游戏标题和介绍
    gameContainer.innerHTML = `
        <h2>改革开放决策模拟</h2>
        <p class="game-intro">体验不同历史时期的重大决策过程，了解政策选择对中国发展的影响</p>
        
        <div class="game-scenario-selector">
            <h3>选择历史时期</h3>
            <div class="scenario-buttons"></div>
        </div>
        
        <div class="game-content">
            <div class="scenario-era"></div>
            <h3 class="scenario-title"></h3>
            <p class="scenario-background"></p>
            
            <div class="decision-options"></div>
            
            <div class="decision-result" style="display: none;">
                <h4>决策结果分析</h4>
                <div class="result-short-term"></div>
                <div class="result-long-term"></div>
                <div class="result-historical-impact"></div>
                <div class="result-gdp-change"></div>
                
                <div class="historical-comparison">
                    <h5>历史对照</h5>
                    <p>查看同期的实际历史决策，请点击时间轴中的相关事件。</p>
                </div>
            </div>
        </div>
        
        <div class="game-stats">
            <h3>你的决策得分</h3>
            <div class="total-score">0</div>
            <div class="score-explanation">得分基于决策对经济增长的影响和历史合理性</div>
        </div>
    `;

    // 添加样式
    addGameStyles();

    // 渲染场景选择按钮
    renderScenarioButtons();

    // 初始化游戏状态
    window.decisionGameState = {
        totalScore: 0,
        completedScenarios: [],
        currentScenarioIndex: 0
    };
    
    // 初始加载第一个场景（1978-1984年）
    loadScenario(decisionScenarios[0].id);
}

// 添加游戏样式
function addGameStyles() {
    const style = document.createElement('style');
    style.textContent = `
        .game-container {
            margin-top: 50px;
            background-color: white;
            padding: 30px;
            border-radius: 5px;
            box-shadow: 0 3px 5px rgba(0,0,0,0.1);
        }
        
        .game-intro {
            margin-bottom: 30px;
            color: #666;
        }
        
        .game-scenario-selector {
            margin-bottom: 30px;
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 5px;
        }
        
        .scenario-buttons {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 15px;
        }
        
        .scenario-btn {
            padding: 10px 15px;
            background-color: #e74c3c;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        
        .scenario-btn:hover {
            background-color: #c8161d;
        }
        
        .scenario-btn.active {
            background-color: #c8161d;
        }
        
        .scenario-era {
            color: #c8161d;
            font-weight: bold;
            margin-bottom: 10px;
        }
        
        .scenario-background {
            margin-bottom: 20px;
            padding: 15px;
            background-color: #f5f5f5;
            border-radius: 5px;
        }
        
        .decision-options {
            display: flex;
            flex-direction: column;
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .option-btn {
            padding: 15px;
            background-color: #f0f0f0;
            color: #333;
            border: 2px solid #ddd;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s;
            text-align: left;
        }
        
        .option-btn:hover {
            background-color: #e74c3c;
            color: white;
            border-color: #e74c3c;
        }
        
        .decision-result {
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 5px;
            margin-top: 30px;
        }
        
        .decision-result h4 {
            color: #c8161d;
            margin-top: 0;
            border-bottom: 1px solid #ddd;
            padding-bottom: 10px;
        }
        
        .result-short-term,
        .result-long-term,
        .result-historical-impact,
        .result-gdp-change {
            margin-bottom: 15px;
            padding: 10px;
            background-color: white;
            border-radius: 5px;
        }
        
        .historical-comparison {
            margin-top: 20px;
            padding: 15px;
            background-color: #e8f4ea;
            border-radius: 5px;
        }
        
        .game-stats {
            margin-top: 30px;
            padding: 20px;
            background-color: #f0f0f0;
            border-radius: 5px;
            text-align: center;
        }
        
        .total-score {
            font-size: 2em;
            font-weight: bold;
            color: #c8161d;
            margin: 10px 0;
        }
        
        .score-explanation {
            color: #666;
            font-size: 0.9em;
        }
        
        /* 暗黑模式样式适配 */
        .dark-mode .game-container,
        .dark-mode .game-scenario-selector,
        .dark-mode .scenario-background,
        .dark-mode .decision-result,
        .dark-mode .result-short-term,
        .dark-mode .result-long-term,
        .dark-mode .result-historical-impact,
        .dark-mode .result-gdp-change,
        .dark-mode .game-stats {
            background-color: #2d2d2d;
            color: #f0f0f0;
        }
        
        .dark-mode .option-btn {
            background-color: #444;
            border-color: #555;
            color: #f0f0f0;
        }
        
        .dark-mode .historical-comparison {
            background-color: #1e3a2a;
        }
        
        @media (max-width: 768px) {
            .scenario-buttons {
                flex-direction: column;
            }
            
            .game-container {
                padding: 20px;
            }
        }
    `;
    document.head.appendChild(style);
}

// 渲染场景选择按钮 - 按顺序解锁
function renderScenarioButtons() {
    const buttonsContainer = document.querySelector('.scenario-buttons');
    
    // 确保游戏状态已初始化
    if (!window.decisionGameState) {
        window.decisionGameState = {
            totalScore: 0,
            completedScenarios: [],
            currentScenarioIndex: 0
        };
    }
    
    decisionScenarios.forEach((scenario, index) => {
        const button = document.createElement('button');
        button.className = 'scenario-btn';
        button.textContent = scenario.era;
        
        // 检查是否可点击：只能点击当前场景和已完成的场景
        const isCompleted = window.decisionGameState.completedScenarios.includes(index);
        const isCurrent = index === window.decisionGameState.currentScenarioIndex;
        
        if (isCompleted || isCurrent) {
            button.addEventListener('click', () => {
                // 移除其他按钮的active类
                document.querySelectorAll('.scenario-btn').forEach(btn => {
                    btn.classList.remove('active');
                });
                // 添加当前按钮的active类
                button.classList.add('active');
                // 加载场景
                loadScenario(scenario.id);
            });
        } else {
            // 未解锁的场景添加锁定样式
            button.disabled = true;
            button.style.backgroundColor = '#ccc';
            button.style.cursor = 'not-allowed';
            button.style.opacity = '0.6';
        }
        
        buttonsContainer.appendChild(button);
    });
}

// 加载场景
function loadScenario(scenarioId) {
    const scenario = decisionScenarios.find(s => s.id === scenarioId);
    if (!scenario) return;
    
    // 更新场景信息
    document.querySelector('.scenario-era').textContent = scenario.era;
    document.querySelector('.scenario-title').textContent = scenario.title;
    document.querySelector('.scenario-background').textContent = scenario.background;
    
    // 渲染选项
    const optionsContainer = document.querySelector('.decision-options');
    optionsContainer.innerHTML = '';
    
    scenario.options.forEach(option => {
        const optionButton = document.createElement('button');
        optionButton.className = 'option-btn';
        optionButton.textContent = option.text;
        optionButton.addEventListener('click', () => {
            // 显示决策结果
            showDecisionResult(option.result);
            // 更新得分
            updateScore(option.result.gdpChange);
            
            // 标记当前场景为已完成
            const scenarioIndex = decisionScenarios.findIndex(s => s.id === scenarioId);
            if (scenarioIndex !== -1 && !window.decisionGameState.completedScenarios.includes(scenarioIndex)) {
                window.decisionGameState.completedScenarios.push(scenarioIndex);
                
                // 解锁下一个场景（如果有）
                if (scenarioIndex < decisionScenarios.length - 1) {
                    window.decisionGameState.currentScenarioIndex = scenarioIndex + 1;
                    
                    // 2秒后自动跳转到下一个场景
                    setTimeout(() => {
                        // 重新渲染按钮以解锁下一个场景
                        document.querySelector('.scenario-buttons').innerHTML = '';
                        renderScenarioButtons();
                        
                        // 加载下一个场景
                        loadScenario(decisionScenarios[scenarioIndex + 1].id);
                    }, 3000);
                } else {
                    // 如果是最后一个场景，显示最终评价
                    setTimeout(() => {
                        showFinalEvaluation();
                    }, 3000);
                }
            }
        });
        optionsContainer.appendChild(optionButton);
    });
    
    // 隐藏结果区域
    document.querySelector('.decision-result').style.display = 'none';
}

// 显示决策结果
function showDecisionResult(result) {
    const resultContainer = document.querySelector('.decision-result');
    
    document.querySelector('.result-short-term').innerHTML = `<strong>短期影响：</strong>${result.shortTerm}`;
    document.querySelector('.result-long-term').innerHTML = `<strong>长期影响：</strong>${result.longTerm}`;
    document.querySelector('.result-historical-impact').innerHTML = `<strong>历史意义：</strong>${result.historicalImpact}`;
    
    // GDP变化显示
    const gdpChangeEl = document.querySelector('.result-gdp-change');
    let gdpChangeText = `<strong>对GDP的影响：</strong>`;
    if (result.gdpChange > 0) {
        gdpChangeText += `+${result.gdpChange}%（促进经济增长）`;
    } else if (result.gdpChange < 0) {
        gdpChangeText += `${result.gdpChange}%（抑制经济增长）`;
    } else {
        gdpChangeText += `0%（基本无影响）`;
    }
    gdpChangeEl.innerHTML = gdpChangeText;
    
    // 显示结果区域
    resultContainer.style.display = 'block';
    
    // 滚动到结果区域
    resultContainer.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// 更新得分
function updateScore(change) {
    if (!window.decisionGameState) {
        window.decisionGameState = {
            totalScore: 0,
            completedScenarios: [],
            currentScenarioIndex: 0
        };
    }
    
    // 计算新得分（基础分0，加上变化值）
    window.decisionGameState.totalScore = Math.max(0, window.decisionGameState.totalScore + change);
    
    // 更新显示
    document.querySelector('.total-score').textContent = window.decisionGameState.totalScore;
}

// 显示最终评价
function showFinalEvaluation() {
    const totalScore = window.decisionGameState.totalScore;
    let evaluation = '';
    
    // 根据得分生成评价
    if (totalScore >= 25) {
        evaluation = `
            <div class="evaluation-excellent">
                <h3>🎉 卓越的决策者！</h3>
                <p>你的决策得分：<strong>${totalScore}</strong></p>
                <p>你展现了卓越的战略眼光和决策能力，几乎每次都做出了符合历史发展规律的选择。你的决策路径与中国改革开放的实际进程高度契合，体现了对国情的深刻理解和对发展规律的准确把握。</p>
                <p>在现实中，正是这样的渐进式改革和精准决策，推动了中国经济的腾飞和社会的全面进步。</p>
            </div>
        `;
    } else if (totalScore >= 15) {
        evaluation = `
            <div class="evaluation-good">
                <h3>👍 优秀的决策者！</h3>
                <p>你的决策得分：<strong>${totalScore}</strong></p>
                <p>你做出了大多数正确的决策，展现了良好的战略思维。你的决策路径总体上符合中国改革开放的发展方向，体现了对历史趋势的准确判断。</p>
                <p>虽然在某些关键节点上可以更加优化，但你的整体表现已经非常出色。</p>
            </div>
        `;
    } else if (totalScore >= 5) {
        evaluation = `
            <div class="evaluation-fair">
                <h3>😊 合格的决策者</h3>
                <p>你的决策得分：<strong>${totalScore}</strong></p>
                <p>你做出了一些正确的决策，但在部分关键节点上的选择还有待优化。你的决策路径反映了对改革开放复杂性的初步理解，也展示了探索不同发展可能的勇气。</p>
                <p>通过学习历史经验，你可以进一步提升决策水平。</p>
            </div>
        `;
    } else {
        evaluation = `
            <div class="evaluation-need-improvement">
                <h3>📚 需要更多学习</h3>
                <p>你的决策得分：<strong>${totalScore}</strong></p>
                <p>改革开放是一项前无古人的伟大事业，需要在实践中不断探索和学习。通过回顾历史，我们可以更好地理解为什么某些决策能够推动经济社会发展，而另一些则会带来挑战。</p>
                <p>建议你再次体验这个模拟游戏，结合实际历史进程，深入思考不同决策的影响。</p>
            </div>
        `;
    }
    
    // 创建评价容器
    const evaluationContainer = document.createElement('div');
    evaluationContainer.id = 'final-evaluation';
    evaluationContainer.className = 'final-evaluation';
    evaluationContainer.innerHTML = `
        <h2>改革开放决策之旅总结</h2>
        <p>你已经完成了所有历史时期的决策挑战，让我们来看看你的决策表现：</p>
        ${evaluation}
        
        <div class="historical-summary">
            <h3>历史启示</h3>
            <p>中国改革开放的成功，得益于坚持解放思想、实事求是，坚持渐进式改革路径，坚持把马克思主义基本原理同中国具体实际相结合。通过这次模拟体验，希望你能更深刻地理解改革开放的复杂性、艰巨性和伟大意义。</p>
        </div>
    `;
    
    // 添加到游戏容器
    const gameContainer = document.querySelector('.game-container');
    gameContainer.innerHTML = '';
    gameContainer.appendChild(evaluationContainer);
    
    // 添加评价样式
    const style = document.createElement('style');
    style.textContent = `
        .final-evaluation {
            text-align: center;
            padding: 30px;
        }
        
        .evaluation-excellent {
            background-color: #d4edda;
            color: #155724;
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
        }
        
        .evaluation-good {
            background-color: #d1ecf1;
            color: #0c5460;
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
        }
        
        .evaluation-fair {
            background-color: #fff3cd;
            color: #856404;
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
        }
        
        .evaluation-need-improvement {
            background-color: #f8d7da;
            color: #721c24;
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
        }
        
        .historical-summary {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
        }
        
        .dark-mode .final-evaluation {
            background-color: #2d2d2d;
            color: #f0f0f0;
        }
        
        .dark-mode .historical-summary {
            background-color: #3d3d3d;
        }
    `;
    document.head.appendChild(style);
}

// 导出函数，供外部调用
window.createDecisionGame = createDecisionGame;

// 页面加载完成后自动初始化游戏
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', createDecisionGame);
} else {
    createDecisionGame();
}
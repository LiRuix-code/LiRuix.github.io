// 在不修改源代码的情况下注册service worker
if ('serviceWorker' in navigator) {
  // 确保DOM加载完毕后再注册service worker
  document.addEventListener('DOMContentLoaded', function() {
    // 尝试注册service worker
    navigator.serviceWorker.register('./service-worker.js')
      .then(function(registration) {
        console.log('Service Worker 注册成功:', registration.scope);
        
        // 监听更新事件
        registration.onupdatefound = function() {
          console.log('发现新的Service Worker版本');
          const installingWorker = registration.installing;
          
          installingWorker.onstatechange = function() {
            switch (installingWorker.state) {
              case 'installed':
                if (navigator.serviceWorker.controller) {
                  // 新的service worker已经安装，但需要用户刷新页面才能激活
                  console.log('新的内容已经可用，请刷新页面');
                  showUpdateNotification();
                } else {
                  // 首次安装，所有内容已缓存
                  console.log('内容已缓存，离线可用');
                }
                break;
              case 'redundant':
                console.log('安装失败，Service Worker被替换');
                break;
            }
          };
        };
      })
      .catch(function(error) {
        console.error('Service Worker 注册失败:', error);
      });
  });
}

// 显示更新通知的函数
function showUpdateNotification() {
  // 检查是否已经存在通知元素
  let notification = document.getElementById('pwa-update-notification');
  
  if (!notification) {
    // 创建通知元素
    notification = document.createElement('div');
    notification.id = 'pwa-update-notification';
    notification.style.cssText = `
      position: fixed;
      bottom: 20px;
      left: 50%;
      transform: translateX(-50%);
      background-color: #c8161d;
      color: white;
      padding: 15px 25px;
      border-radius: 5px;
      box-shadow: 0 3px 10px rgba(0,0,0,0.2);
      z-index: 9999;
      display: flex;
      align-items: center;
      gap: 10px;
    `;
    
    // 添加消息文本
    const message = document.createElement('span');
    message.textContent = '网站有更新，点击刷新获取最新内容';
    
    // 添加刷新按钮
    const refreshBtn = document.createElement('button');
    refreshBtn.textContent = '刷新';
    refreshBtn.style.cssText = `
      background-color: white;
      color: #c8161d;
      border: none;
      padding: 5px 10px;
      border-radius: 3px;
      cursor: pointer;
      font-weight: bold;
    `;
    
    refreshBtn.addEventListener('click', function() {
      // 刷新页面以激活新的service worker
      window.location.reload();
    });
    
    // 添加关闭按钮
    const closeBtn = document.createElement('span');
    closeBtn.textContent = '×';
    closeBtn.style.cssText = `
      cursor: pointer;
      font-size: 18px;
      font-weight: bold;
    `;
    
    closeBtn.addEventListener('click', function() {
      notification.style.display = 'none';
    });
    
    // 组装通知元素
    notification.appendChild(message);
    notification.appendChild(refreshBtn);
    notification.appendChild(closeBtn);
    
    // 添加到页面
    document.body.appendChild(notification);
  } else {
    // 显示已存在的通知元素
    notification.style.display = 'flex';
  }
}

// 检查是否有新的service worker在等待激活
function checkForWaitingServiceWorker() {
  navigator.serviceWorker.register('./service-worker.js')
    .then(registration => {
      if (registration.waiting) {
        showUpdateNotification();
      }
    });
}

// 监听页面加载完成后的service worker状态
window.addEventListener('load', function() {
  // 检查是否有等待激活的service worker
  checkForWaitingServiceWorker();
  
  // 定期检查更新（每小时）
  setInterval(checkForWaitingServiceWorker, 3600000);
});

// 监听service worker消息
navigator.serviceWorker.addEventListener('message', event => {
  if (event.data && event.data.type === 'UPDATE_AVAILABLE') {
    showUpdateNotification();
  }
});
// 缓存版本号，用于更新缓存
const CACHE_VERSION = 'reform-opening-v1';

// 需要缓存的关键资源
const CACHE_ASSETS = [
  './',
  './index.html',
  './style.css',
  './script.js',
  './enhancements.js',
  './manifest.json',
  // 缓存图片资源
  './images/1978.jpg',
  './images/1979.png',
  './images/1982.webp',
  './images/1984.webp',
  './images/1986.jpg',
  './images/1990.jpg',
  './images/1992.webp',
  './images/1994.webp',
  './images/1997.jpg',
  './images/2001.jpg',
  './images/2006.jpg',
  './images/2013.jpg',
  './images/2017.avif',
  './images/2018.jpg',
  './images/2020.jpg'
];

// 安装阶段 - 缓存所有关键资源
self.addEventListener('install', event => {
  console.log('Service Worker 正在安装');
  event.waitUntil(
    caches.open(CACHE_VERSION)
      .then(cache => {
        console.log('开始缓存资源');
        return cache.addAll(CACHE_ASSETS);
      })
      .then(() => {
        console.log('资源缓存完成');
        // 跳过等待，直接激活新的service worker
        return self.skipWaiting();
      })
  );
});

// 激活阶段 - 删除旧缓存
self.addEventListener('activate', event => {
  console.log('Service Worker 正在激活');
  event.waitUntil(
    caches.keys()
      .then(cacheNames => {
        // 删除旧版本的缓存
        return Promise.all(
          cacheNames.map(cacheName => {
            if (cacheName !== CACHE_VERSION) {
              console.log('删除旧缓存:', cacheName);
              return caches.delete(cacheName);
            }
          })
        );
      })
      .then(() => {
        // 接管所有页面
        return self.clients.claim();
      })
  );
});

// 拦截网络请求 - 优先从缓存返回资源
self.addEventListener('fetch', event => {
  // 只处理同源请求
  if (event.request.url.startsWith(self.location.origin)) {
    event.respondWith(
      caches.match(event.request)
        .then(response => {
          // 如果缓存中有匹配的资源，直接返回
          if (response) {
            console.log('从缓存返回资源:', event.request.url);
            return response;
          }
          
          // 缓存中没有，则发起网络请求
          console.log('从网络请求资源:', event.request.url);
          return fetch(event.request)
            .then(fetchResponse => {
              // 如果请求成功，将响应克隆并缓存
              if (fetchResponse && fetchResponse.status === 200) {
                const responseToCache = fetchResponse.clone();
                caches.open(CACHE_VERSION)
                  .then(cache => {
                    cache.put(event.request, responseToCache);
                  });
              }
              return fetchResponse;
            })
            .catch(error => {
              console.error('网络请求失败:', error);
              // 可以在这里返回一个离线备用页面
              // 但为了简化，我们直接返回缓存中的首页
              return caches.match('./index.html');
            });
        })
    );
  }
});

// 监听消息事件，用于手动更新缓存
self.addEventListener('message', event => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});